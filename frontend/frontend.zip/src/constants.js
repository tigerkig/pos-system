export const SIGNED_IN = 'SIGNED_IN';
export const USER_TYPE = 'USER_TYPE';
